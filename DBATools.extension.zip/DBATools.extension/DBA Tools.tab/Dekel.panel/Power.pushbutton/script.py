# -*- coding: utf-8 -*-
"""Dekel Power Equipment Tool"""

__title__   = "Power"
__doc__     = u"Matches Electrical Equipment & Fixtures to Dekel codes."
__author__  = "Yamit Bettman"

import re, os, codecs, zipfile
import xml.etree.ElementTree as ET

import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
clr.AddReference("System")

from System.Windows.Forms import (
    OpenFileDialog, DialogResult,
    Form, Label, Button, ListView, ListViewItem,
    ColumnHeader, View, HorizontalAlignment,
    FormStartPosition, FormBorderStyle,
    RightToLeft as WinRTL, Panel, FlatStyle,
)
from System.Drawing import Font, FontStyle, Color, Size, Point
import System

from Autodesk.Revit.DB import (
    Transaction, BuiltInCategory, FilteredElementCollector,
    CategorySet, InstanceBinding, ElementId, BuiltInParameterGroup,
)
from Autodesk.Revit.UI import TaskDialog
from System.Collections.Generic import List as CList
from pyrevit import revit

doc   = revit.doc
uidoc = revit.uidoc
NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"

PARAM_CODE  = u"מספר סעיף דקל"
PARAM_DESC  = u"תיאור סעיף דקל"
PARAM_PRICE = u"מחיר דקל"
PARAM_CODE2  = u"מספר סעיף דקל 2"
PARAM_DESC2  = u"תיאור סעיף דקל 2"
PARAM_PRICE2 = u"מחיר דקל 2"
PARAM_DEFS = [
    (PARAM_CODE, u"TEXT"), (PARAM_DESC, u"TEXT"), (PARAM_PRICE, u"NUMBER"),
    (PARAM_CODE2, u"TEXT"),(PARAM_DESC2, u"TEXT"),(PARAM_PRICE2, u"NUMBER"),
]

EQUIPMENT_MAP = {
    u"DBA Transformer - Dry Type - 630 kVA":  (u"08.093.0100", u"שנאי יבש 630kVA"),
    u"DBA Transformer - Dry Type - 800 kVA":  (u"08.093.0110", u"שנאי יבש 800kVA"),
    u"DBA Transformer - Dry Type - 1000 kVA": (u"08.093.0120", u"שנאי יבש 1000kVA"),
    u"DBA Transformer - Dry Type - 1250 kVA": (u"08.093.0125", u"שנאי יבש 1250kVA"),
    u"DBA Transformer - Dry Type - 1600 kVA": (u"08.093.0126", u"שנאי יבש 1600kVA"),
    u"DBA Transformer - Dry Type - 2000 kVA": (u"08.093.0127", u"שנאי יבש 2000kVA"),
    u"DBA Transformer - Oil Type - 630 kVA":  (u"08.093.0040", u"שנאי שמן 630kVA"),
    u"DBA Transformer - Oil Type - 800 kVA":  (u"08.093.0050", u"שנאי שמן 800kVA"),
    u"DBA Transformer - Oil Type - 1000 kVA": (u"08.093.0060", u"שנאי שמן 1000kVA"),
    u"DBA Transformer - Oil Type - 1250 kVA": (u"08.093.0070", u"שנאי שמן 1250kVA"),
    u"DBA Transformer - Oil Type - 1600 kVA": (u"08.093.0075", u"שנאי שמן 1600kVA"),
    u"DBA Transformer - Oil Type - 2000 kVA": (u"08.093.0077", u"שנאי שמן 2000kVA"),
    u"DBA Transformer Control Panel":         (u"08.093.0200", u"קופסת פיקוד לשנאי"),
    u"DBA Uninterruptible Power Supply - 10 kVA": (u"08.048.1100", u"מערכת אל-פסק 10kVA"),
    u"DBA Uninterruptible Power Supply - 20 kVA": (u"08.048.1120", u"מערכת אל-פסק 20kVA"),
    u"DBA Uninterruptible Power Supply - 40 kVA": (u"08.048.1140", u"מערכת אל-פסק 40kVA"),
    u"DBA Uninterruptible Power Supply - 80 kVA": (u"08.048.1160", u"מערכת אל-פסק 80kVA"),
    u"DBA HV Circuit Breaker Switchboard":    (u"08.095.0010", u"לוח מתח גבוה"),
    u"DBA Fire Alarm Control Panel":          (u"08.019.0490", u"רכזת גילוי אש"),
    u"DBA Circuit Breaker Switchboard":       (None, u"לוח ראשי - 08.061"),
    u"DBA Panelboard - 400V MCB - Recessed":  (None, u"לוח תחת הטיח - 08.061"),
    u"DBA Panelboard - 400V MCB - Surface":   (None, u"לוח על הטיח - 08.061"),
    u"Diesel Emergency Power Generator":      (None, u"דורש הצעת ספק"),
    u"DBA Fire Fighter Control Panel":        (None, u"לוח כבאים - תמחור מיוחד"),
    u"DBA Smoke Release Windows Control Unit":(None, u"רכזת חלונות עשן - תמחור מיוחד"),
}

SWITCHBOARD_CELLS = [
    (400,600,"08.061.0050"),(400,800,"08.061.0060"),(600,600,"08.061.0080"),
    (800,600,"08.061.0090"),(800,800,"08.061.0110"),(1000,600,"08.061.0120"),
    (1000,800,"08.061.0130"),(1200,800,"08.061.0131"),(2000,400,"08.061.0048"),
    (2000,600,"08.061.0046"),(2000,800,"08.061.0044"),(2000,1000,"08.061.0042"),
    (2200,400,"08.061.0040"),(2200,600,"08.061.0030"),(2200,800,"08.061.0020"),
    (2200,1000,"08.061.0010"),
]
PANELBOARD_MCB = {
    25:(u"08.061.0640",u"08.061.0600"),40:(u"08.061.0650",u"08.061.0610"),
    63:(u"08.061.0660",u"08.061.0620"),80:(u"08.061.0670",u"08.061.0630"),
    100:(u"08.061.0675",u"08.061.0632"),125:(u"08.061.0680",u"08.061.0635"),
}

FIXTURE_MAP = {
    u"DBA Load Break Switch - 2P 16A":(u"08.073.0211",u"מפסק 2X16A",u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Load Break Switch - 2P 25A":(u"08.073.0231",u"מפסק 2X25A",u"08.019.0320",u"נקודה 4mm²"),
    u"DBA Load Break Switch - 4P 16A":(u"08.073.0232",u"מפסק 4X16A",u"08.019.0340",u"נקודה 3P 2.5mm²"),
    u"DBA Load Break Switch - 4P 32A":(u"08.073.0233",u"מפסק 4X32A",u"08.019.0350",u"נקודה 3P 4mm²"),
    u"DBA Load Break Switch - 4P 63A":(u"08.073.0245",u"מפסק 4X63A",u"08.019.0350",u"נקודה 3P 4mm²"),
    u"DBA Mounted Socket - x1":(u"08.072.0023",u'שקע עה"ט x1',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Mounted Socket - x2":(u"08.072.0024",u'שקע עה"ט x2',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Mounted Socket - x3":(u"08.072.0025",u'שקע עה"ט x3',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Mounted Socket - x4":(u"08.072.0026",u'שקע עה"ט x4',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Mounted Socket - AC":(u"08.019.0100",u"נקודה מזגן",None,u""),
    u"DBA Recessed Socket - x1":(u"08.072.0090",u'שקע תה"ט x1',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Recessed Socket - x2":(u"08.072.0090",u'שקע תה"ט x2',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Recessed Socket - x3":(u"08.072.0090",u'שקע תה"ט x3',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Recessed Socket - x4":(u"08.072.0090",u'שקע תה"ט x4',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Recessed Socket - AC":(u"08.019.0100",u"נקודה מזגן",None,u""),
    u"DBA Recessed 3P Socket - AC":(u"08.019.0167",u"נקודה מזגן 3P",None,u""),
    u"DBA Mounted 3P Socket":(u"08.019.0430",u"נקודה תלת-פאזי",None,u""),
    u"DBA Recessed 3P Socket":(u"08.019.0430",u"נקודה תלת-פאזי",None,u""),
    u"DBA CEE Socket - 1x16A CEE":(u"08.072.0040",u"שקע CEE 3P 16A",u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA CEE Socket - 3x16A CEE":(u"08.072.0060",u"שקע CEE 5P 16A",u"08.019.0340",u"נקודה 3P"),
    u"DBA EV Charging Station - 60 X 25 X 25 cm 11kW":(u"08.050.0210",u"עמדת טעינה 11kW",None,u""),
    u"DBA EV Charging Station - 125 x 35 x 50 cm 22kW":(u"08.050.0220",u"עמדת טעינה 22kW",None,u""),
    u"DBA EV Charging Station":(u"08.050.0210",u"עמדת טעינה",None,u""),
    u"DBA Thermostat - AC Mounted":(u"08.046.0390",u"תרמוסטט",u"08.019.0475",u"נקודת תרמוסטט"),
    u"DBA Thermostat - AC Recessed":(u"08.046.0390",u"תרמוסטט",u"08.019.0475",u"נקודת תרמוסטט"),
    u"DBA Thermostat - Underfloor Heating":(u"08.046.0380",u"תרמוסטט רצפה",u"08.019.0475",u"נקודת תרמוסטט"),
    u"DBA Recessed Electric Shade-Curtain":(u"08.019.0800",u"נקודת תריס",None,u""),
    u"DBA Push Button":(u"08.073.0510",u'לחצן חירום תה"ט',None,u""),
    u"DBA Recessed Doorbell":(u"08.019.0205",u"נקודת פעמון",None,u""),
    u"DBA Waterproof Mounted Socket - x1":(u"08.072.0023",u'שקע עה"ט x1',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Waterproof Mounted Socket - x2":(u"08.072.0024",u'שקע עה"ט x2',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Waterproof Mounted Socket":(u"08.019.0410",u"נקודה 2.5mm²",None,u""),
    u"DBA Waterproof Recessed Socket - x1":(u"08.072.0090",u'שקע תה"ט x1',u"08.019.0310",u"נקודה 2.5mm²"),
    u"DBA Waterproof Recessed Socket":(u"08.019.0310",u"נקודה 2.5mm²",None,u""),
    u"DBA Recessed Switched Socket":(u"08.019.0400",u"נקודה 1.5mm²",None,u""),
    u"DBA Grounding Out":(u"08.040.0110",u"פס 30×3.5",None,u""),
    u"DBA Grounding Out - Elevator":(u"08.040.0120",u"פס 40×4 מעלית",None,u""),
    u"DBA Grounding Out - Strip":(u"08.040.0120",u"פס 40×4",None,u""),
    u"DBA Grounding Down":(u"08.040.0110",u"מוליך הורדה",None,u""),
    u"DBA Grounding Up":(u"08.040.0110",u"מוליך עלייה",None,u""),
    u"DBA Grounding Pit":(u"08.040.0020",u"שוחת ביקורת",None,u""),
    u"DBA Grounding Pot":(u"08.040.0025",u"שוחת ביקורת פלסטית",None,u""),
    u"DBA Grounding Flex Connection":(u"08.040.0100",u"גשר הארקה",None,u""),
    u"DBA Grounding Antistatic Floor":(u"08.040.0050",u"נקודת הארקה 16mm²",None,u""),
    u"DBA Grounding Recessed Junction Box":(u"08.026.0150",u"תיבת הארקת יסוד",None,u""),
    u"DBA Recessed Grounding Junction Box":(u"08.026.0150",u"תיבת הארקת יסוד",None,u""),
    u"DBA Recessed Junction Box":(u"08.026.0160",u"קופסת הסתעפות IP65",None,u""),
    u"DBA Socket Column":(u"08.072.0820",u"קופסת שקעים",None,u""),
    u"DBA Industrial Combi Box":(u"08.072.1000",u"קופסת שירות CEE+ישראלי",None,u""),
    u"DBA Floor Sockets":(u"08.072.0820",u"קופסת שקעים",None,u""),
    u"DBA Mounted Armatura -Bath Heater":(u"08.019.0410",u"נקודה 2.5mm²",None,u""),
    u"DBA Round Opening":(None,u"פתח עגול — ללא סעיף",None,u""),
    u"DBA Square Opening":(None,u"פתח מרובע — ללא סעיף",None,u""),
    u"DBA Mounted Elec Workstation":(None,u"תחנת עבודה — דורש תמחור",None,u""),
    u"DBA Recessed Elec WorkStation":(None,u"תחנת עבודה — דורש תמחור",None,u""),
    u"DBA Mounted Elec Workstation with UPS":(None,u"תחנת עבודה + UPS",None,u""),
    u"DBA Recessed Elec WorkStation with UPS":(None,u"תחנת עבודה + UPS",None,u""),
}

# ── Shared parameters ─────────────────────────────────────────────────────────
def get_existing():
    s=set(); it=doc.ParameterBindings.ForwardIterator()
    while it.MoveNext(): s.add(it.Key.Name)
    return s

def create_params(missing):
    spf=os.path.join(str(System.Environment.GetFolderPath(
        System.Environment.SpecialFolder.ApplicationData)),"DekelPower_tmp.txt")
    hdr=(u"# Revit Shared Parameters\n*META\tVERSION\tMINVERSION\nMETA\t2\t1\n"
         u"*GROUP\tID\tNAME\nGROUP\t1\tDekel\n"
         u"*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUEISSHOWN\n")
    lines=u"".join(u"PARAM\t{}\t{}\t{}\t\t1\t1\t\t1\t0\n".format(str(System.Guid.NewGuid()),n,t) for n,t in missing)
    import codecs
    with codecs.open(spf,"w",encoding="utf-16") as f: f.write(hdr+lines)
    old=doc.Application.SharedParametersFilename
    doc.Application.SharedParametersFilename=spf
    try:
        sp=doc.Application.OpenSharedParameterFile()
        grp=sp.Groups.get_Item("Dekel")
        cats=CategorySet()
        for bic in [BuiltInCategory.OST_ElectricalEquipment,BuiltInCategory.OST_ElectricalFixtures]:
            cats.Insert(doc.Settings.Categories.get_Item(bic))
        for n,_ in missing:
            d=grp.Definitions.get_Item(n)
            if d:
                doc.ParameterBindings.Insert(d,InstanceBinding(cats),BuiltInParameterGroup.INVALID)
                print(u"  נוצר: {}".format(n))
    finally:
        doc.Application.SharedParametersFilename=old or ""
        try: os.remove(spf)
        except: pass

def ensure_cats():
    tgt=[doc.Settings.Categories.get_Item(b) for b in
         [BuiltInCategory.OST_ElectricalEquipment,BuiltInCategory.OST_ElectricalFixtures]]
    pnames=set(n for n,_ in PARAM_DEFS)
    defs=[]
    it=doc.ParameterBindings.ForwardIterator()
    while it.MoveNext():
        if it.Key.Name in pnames: defs.append(it.Key)
    for d in defs:
        b=doc.ParameterBindings.get_Item(d)
        if not b: continue
        cats=b.Categories
        for cat in tgt: cats.Insert(cat)
        doc.ParameterBindings.ReInsert(d,InstanceBinding(cats),BuiltInParameterGroup.INVALID)

missing=[(n,t) for n,t in PARAM_DEFS if n not in get_existing()]
if missing:
    t0=Transaction(doc,u"Dekel Power - Params"); t0.Start()
    try: create_params(missing); t0.Commit()
    except Exception as e: t0.RollBack(); TaskDialog.Show("Dekel",u"{}".format(e)); import sys; sys.exit()
else: print(u"פרמטרים קיימים.")
tb=Transaction(doc,u"Dekel Power - Bind"); tb.Start()
try: ensure_cats(); tb.Commit()
except Exception as e: tb.RollBack(); print(u"אזהרה: {}".format(e))

# ── Excel dialog & read ───────────────────────────────────────────────────────
dlg=OpenFileDialog(); dlg.Title=u"בחר קובץ טבלת דקל"; dlg.Filter="Excel Files (*.xlsx)|*.xlsx"
if dlg.ShowDialog()!=DialogResult.OK:
    TaskDialog.Show("Dekel",u"לא נבחר קובץ."); import sys; sys.exit()
excel_path=dlg.FileName; print(u"קובץ: {}".format(excel_path))

def ci(ref):
    m=re.match(r"([A-Za-z]+)",ref)
    if not m: return 0
    idx=0
    for ch in m.group(1).upper(): idx=idx*26+(ord(ch)-64)
    return idx-1

def cv(c,shared):
    ie=c.find("{%s}is"%NS)
    if ie is not None: return u"".join(t.text or u"" for t in ie.iter("{%s}t"%NS))
    v=c.find("{%s}v"%NS)
    if v is None: return None
    if c.get("t","")=="s":
        try: return shared[int(v.text)]
        except: return v.text
    try: return float(v.text)
    except: return v.text

def read_xlsx(path):
    data={}
    with zipfile.ZipFile(path,"r") as z:
        nms=z.namelist(); shared=[]
        if "xl/sharedStrings.xml" in nms:
            root=ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.iter("{%s}si"%NS):
                shared.append(u"".join(t.text or u"" for t in si.iter("{%s}t"%NS)))
        for sf in sorted([n for n in nms if re.match(r"xl/worksheets/sheet\d+\.xml$",n)]):
            root=ET.fromstring(z.read(sf))
            for row in root.iter("{%s}row"%NS):
                rd={}
                for c in row: rd[ci(c.get("r",""))]=cv(c,shared)
                code=u"{}".format(rd.get(0) or "").strip()
                if not re.match(r"\d{2}\.\d{3}\.\d{4}",code): continue
                p=rd.get(3)
                try: p=float(p) if p else None
                except: p=None
                data[code]={"title":u"{}".format(rd.get(1) or "")[:150],"price":p}
    return data

try:
    dekel=read_xlsx(excel_path); print(u"נטענו {} סעיפים".format(len(dekel)))
except Exception as e:
    TaskDialog.Show("Dekel",u"שגיאה:\n{}".format(e)); import sys; sys.exit()

# ── Match helpers ─────────────────────────────────────────────────────────────
def get_ft(elem):
    try: return elem.Symbol.FamilyName.strip(), elem.Symbol.Name.strip()
    except: return u"",u""

def setp(elem,name,val):
    p=elem.LookupParameter(name)
    if not p or p.IsReadOnly: return False
    try:
        st=str(p.StorageType)
        if "String" in st: p.Set(u"{}".format(val))
        elif "Double" in st: p.Set(float(val))
        elif "Integer" in st: p.Set(int(float(val)))
        else: p.Set(float(val))
        return True
    except: return False

CODE_RE=re.compile(r"^\d{2}\.\d{3}\.\d{4}$")

def match_equip(elem):
    fam,typ=get_ft(elem)
    for key in [u"{} - {}".format(fam,typ), fam]:
        if key in EQUIPMENT_MAP:
            code,desc=EQUIPMENT_MAP[key]
            price=dekel.get(code,{}).get("price") if code else None
            return code,desc,price
    if u"Circuit Breaker Switchboard" in fam and u"HV" not in fam:
        nums=re.findall(r"[\d.]+",typ)
        if len(nums)>=2:
            h,w=float(nums[0])*10,float(nums[1])*10
            best=min(SWITCHBOARD_CELLS,key=lambda r:abs(r[0]-h)+abs(r[1]-w))
            code=best[2]; price=dekel.get(code,{}).get("price")
            return code,u"מבנה פח {}×{}".format(int(best[0]),int(best[1])),price
    mcb=re.search(r"(\d+)\s*A",typ)
    if mcb and (u"Panelboard" in fam or u"Panel" in fam):
        amps=int(mcb.group(1)); keys=sorted(PANELBOARD_MCB.keys())
        cl=min(keys,key=lambda k:abs(k-amps))
        code=PANELBOARD_MCB[cl][0] if u"Recessed" in fam else PANELBOARD_MCB[cl][1]
        return code,u"{}A".format(amps),dekel.get(code,{}).get("price")
    return None,None,None

def get_prefilled(elem):
    for n1,n2 in [(u"DBA_\u05de\u05e1' \u05e1\u05e2\u05d9\u05e3 \u05d3\u05e7\u05dc (1)",
                   u"DBA_\u05de\u05e1' \u05e1\u05e2\u05d9\u05e3 \u05d3\u05e7\u05dc (2)")]:
        p1=elem.LookupParameter(n1); p2=elem.LookupParameter(n2)
        c1=(p1.AsString() or u"").strip() if p1 else u""
        c2=(p2.AsString() or u"").strip() if p2 else u""
        if CODE_RE.match(c1) or CODE_RE.match(c2):
            return (c1 if CODE_RE.match(c1) else None,
                    c2 if CODE_RE.match(c2) else None)
    return None,None

def match_fix(elem):
    fam,typ=get_ft(elem)
    c1,c2=get_prefilled(elem)
    if c1 or c2:
        p1=dekel.get(c1,{}).get("price") if c1 else None
        t1=dekel.get(c1,{}).get("title",u"")[:60] if c1 else u""
        p2=dekel.get(c2,{}).get("price") if c2 else None
        t2=dekel.get(c2,{}).get("title",u"")[:60] if c2 else u""
        return c1,t1,p1,c2,t2,p2
    for key in [u"{} - {}".format(fam,typ), fam]:
        if key in FIXTURE_MAP:
            fc1,l1,fc2,l2=FIXTURE_MAP[key]
            p1=dekel.get(fc1,{}).get("price") if fc1 else None
            t1=dekel.get(fc1,{}).get("title",l1)[:60] if fc1 else l1
            p2=dekel.get(fc2,{}).get("price") if fc2 else None
            t2=dekel.get(fc2,{}).get("title",l2)[:60] if fc2 else l2
            return fc1,t1,p1,fc2,t2,p2
    return None,None,None,None,None,None

# ── Collect & update ──────────────────────────────────────────────────────────
equipment=list(FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_ElectricalEquipment)
    .WhereElementIsNotElementType().ToElements())
fixtures=list(FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_ElectricalFixtures)
    .WhereElementIsNotElementType().ToElements())
print(u"ציוד: {}, פיקסצ'רים: {}".format(len(equipment),len(fixtures)))

eq_ok=eq_sk=eq_fl=fx_ok=fx_sk=fx_fl=0
skipped_details=[]; failed_details=[]
_zoom=[None]

t=Transaction(doc,u"Dekel Power - Update")
t.Start()

for elem in equipment:
    eid=str(elem.Id.IntegerValue); fam,typ=get_ft(elem)
    try:
        code,desc,price=match_equip(elem)
        if not code and not desc:
            eq_sk+=1; skipped_details.append((eid,u"{}/{}".format(fam,typ),u"לא נמצאה התאמה")); continue
        if not code:
            eq_sk+=1; skipped_details.append((eid,u"{}/{}".format(fam,typ),desc or u"ללא קוד")); continue
        ok=setp(elem,PARAM_CODE,code); setp(elem,PARAM_DESC,desc or u""); setp(elem,PARAM_PRICE,float(price) if price else 0.0)
        if ok: eq_ok+=1
        else: eq_fl+=1; failed_details.append((eid,u"{}/{}".format(fam,typ),u"כשל כתיבה"))
    except Exception as e:
        eq_fl+=1; failed_details.append((eid,u"{}/{}".format(fam,typ),u"{}".format(e)))

for elem in fixtures:
    eid=str(elem.Id.IntegerValue); fam,typ=get_ft(elem)
    try:
        c1,t1,p1,c2,t2,p2=match_fix(elem)
        if not c1 and not c2 and not t1:
            fx_sk+=1; skipped_details.append((eid,u"{}/{}".format(fam,typ),u"לא נמצאה התאמה")); continue
        if not c1 and t1:
            fx_sk+=1; skipped_details.append((eid,u"{}/{}".format(fam,typ),t1)); continue
        ok=setp(elem,PARAM_CODE,c1 or u""); setp(elem,PARAM_DESC,t1 or u""); setp(elem,PARAM_PRICE,float(p1) if p1 else 0.0)
        if c2:
            setp(elem,PARAM_CODE2,c2); setp(elem,PARAM_DESC2,t2 or u""); setp(elem,PARAM_PRICE2,float(p2) if p2 else 0.0)
        if ok: fx_ok+=1
        else: fx_fl+=1; failed_details.append((eid,u"{}/{}".format(fam,typ),u"כשל כתיבה"))
    except Exception as e:
        fx_fl+=1; failed_details.append((eid,u"{}/{}".format(fam,typ),u"{}".format(e)))

t.Commit()
print(u"ציוד: {}✓ {}⚠ {}✗ | פיקסצ'רים: {}✓ {}⚠ {}✗".format(eq_ok,eq_sk,eq_fl,fx_ok,fx_sk,fx_fl))

# ── Summary dialog ────────────────────────────────────────────────────────────
BG=Color.White; BG2=Color.FromArgb(248,249,251); ACC=Color.FromArgb(37,99,235)
ADIM=Color.FromArgb(42,74,138); TDK=Color.FromArgb(17,24,39)
TMD=Color.FromArgb(75,85,99); TLT=Color.FromArgb(156,163,175)
CSUC=Color.FromArgb(5,150,105); CWRN=Color.FromArgb(217,119,6); CERR=Color.FromArgb(220,38,38)
CSUCBG=Color.FromArgb(220,252,231); CWRNBG=Color.FromArgb(254,243,199); CERRBG=Color.FromArgb(254,226,226)

def mkbtn(t,x,y,w=140,h=38,pri=False):
    b=Button(); b.Text=t; b.Location=Point(x,y); b.Size=Size(w,h)
    b.FlatStyle=FlatStyle.Flat; b.Cursor=System.Windows.Forms.Cursors.Hand
    if pri:
        b.BackColor=ACC; b.ForeColor=Color.White; b.Font=Font(u"Segoe UI",10,FontStyle.Bold)
        b.FlatAppearance.BorderSize=0
    else:
        b.BackColor=BG; b.ForeColor=ACC; b.Font=Font(u"Segoe UI",10)
        b.FlatAppearance.BorderColor=ADIM; b.FlatAppearance.BorderSize=1
    return b

def badge(frm,x,y,val,lbl,clr,bg):
    bx=Panel(); bx.Location=Point(x,y); bx.Size=Size(130,58); bx.BackColor=bg
    lv=Label(); lv.Text=str(val); lv.Font=Font(u"Segoe UI",20,FontStyle.Bold)
    lv.ForeColor=clr; lv.BackColor=bg; lv.Location=Point(8,3); lv.Size=Size(114,30)
    ln=Label(); ln.Text=lbl; ln.Font=Font(u"Segoe UI",9); ln.ForeColor=TMD
    ln.BackColor=bg; ln.Location=Point(8,34); ln.Size=Size(114,18)
    bx.Controls.Add(lv); bx.Controls.Add(ln); frm.Controls.Add(bx)

def show_details_dlg():
    frm=Form(); frm.Text=u"פרטי אלמנטים"; frm.RightToLeft=WinRTL.Yes
    frm.RightToLeftLayout=True; frm.StartPosition=FormStartPosition.CenterScreen
    frm.ClientSize=Size(680,520); frm.BackColor=BG; frm.MinimizeBox=False
    stripe=Panel(); stripe.BackColor=ACC; stripe.Location=Point(0,0); stripe.Size=Size(680,3); frm.Controls.Add(stripe)
    hdr=Panel(); hdr.Location=Point(0,3); hdr.Size=Size(680,48); hdr.BackColor=BG2; frm.Controls.Add(hdr)
    lh=Label(); lh.Text=u"Dekel Power — פרטים"; lh.Font=Font(u"Segoe UI",11,FontStyle.Bold)
    lh.ForeColor=TDK; lh.BackColor=BG2; lh.Location=Point(18,12); lh.Size=Size(350,24); hdr.Controls.Add(lh)
    sep=Panel(); sep.BackColor=Color.FromArgb(229,231,235); sep.Location=Point(0,51); sep.Size=Size(680,1); frm.Controls.Add(sep)
    lbl=Label(); lbl.Text=u"דולגו: {}  |  נכשלו: {}".format(len(skipped_details),len(failed_details))
    lbl.Font=Font(u"Segoe UI",12,FontStyle.Bold); lbl.ForeColor=TDK
    lbl.Location=Point(15,62); lbl.Size=Size(650,26); frm.Controls.Add(lbl)
    hint=Label(); hint.Text=u"לחץ פעמיים על שורה — הצג במודל"
    hint.Font=Font(u"Segoe UI",8.5); hint.ForeColor=TLT
    hint.Location=Point(15,88); hint.Size=Size(650,18); frm.Controls.Add(hint)
    lv=ListView(); lv.View=View.Details; lv.FullRowSelect=True; lv.GridLines=False
    lv.Location=Point(15,112); lv.Size=Size(650,350); lv.RightToLeftLayout=True
    lv.Font=Font(u"Segoe UI",9); lv.BackColor=BG; lv.ForeColor=TDK
    from System.Windows.Forms import BorderStyle as BS; lv.BorderStyle=BS.FixedSingle
    for txt,w in [(u"סטטוס",75),(u"ID",85),(u"אלמנט",150),(u"סיבה",325)]:
        ch=ColumnHeader(); ch.Text=txt; ch.Width=w; ch.TextAlign=HorizontalAlignment.Right; lv.Columns.Add(ch)
    for eid,name,reason in skipped_details:
        it=ListViewItem(u"דולג"); it.ForeColor=CWRN
        it.SubItems.Add(eid); it.SubItems.Add(name); it.SubItems.Add(reason); lv.Items.Add(it)
    for eid,name,reason in failed_details:
        it=ListViewItem(u"נכשל"); it.ForeColor=CERR
        it.SubItems.Add(eid); it.SubItems.Add(name); it.SubItems.Add(reason); lv.Items.Add(it)
    frm.Controls.Add(lv)
    def zoom():
        if lv.SelectedItems.Count==0: return
        try: _zoom[0]=int(lv.SelectedItems[0].SubItems[1].Text); frm.Close()
        except: pass
    lv.ItemActivate+=lambda s,e: zoom()
    bz=mkbtn(u"הצג במודל",15,472,160,38,pri=True); bz.Click+=lambda s,e: zoom(); frm.Controls.Add(bz)
    bc=mkbtn(u"סגור",505,472,160,38); bc.Click+=lambda s,e: frm.Close(); frm.Controls.Add(bc)
    frm.ShowDialog()

total_ok=eq_ok+fx_ok; total_sk=eq_sk+fx_sk; total_fl=eq_fl+fx_fl
frm=Form(); frm.Text=u"Dekel Power Tool — סיכום"; frm.RightToLeft=WinRTL.Yes
frm.RightToLeftLayout=True; frm.StartPosition=FormStartPosition.CenterScreen
frm.FormBorderStyle=FormBorderStyle.FixedSingle; frm.MaximizeBox=False; frm.MinimizeBox=False
frm.ClientSize=Size(450,330); frm.BackColor=BG
stripe=Panel(); stripe.BackColor=ACC; stripe.Location=Point(0,0); stripe.Size=Size(450,3); frm.Controls.Add(stripe)
hdr=Panel(); hdr.Location=Point(0,3); hdr.Size=Size(450,48); hdr.BackColor=BG2; frm.Controls.Add(hdr)
lh=Label(); lh.Text=u"Dekel Power Tool"; lh.Font=Font(u"Segoe UI",11,FontStyle.Bold)
lh.ForeColor=TDK; lh.BackColor=BG2; lh.Location=Point(18,12); lh.Size=Size(250,24); hdr.Controls.Add(lh)
sep=Panel(); sep.BackColor=Color.FromArgb(229,231,235); sep.Location=Point(0,51); sep.Size=Size(450,1); frm.Controls.Add(sep)
lt=Label(); lt.Text=u"העדכון הושלם!"; lt.Font=Font(u"Segoe UI",18,FontStyle.Bold)
lt.ForeColor=TDK; lt.Location=Point(22,62); lt.Size=Size(406,36); frm.Controls.Add(lt)
ls=Label(); ls.Text=u"ציוד: {}  |  פיקסצ'רים: {}".format(len(equipment),len(fixtures))
ls.Font=Font(u"Segoe UI",9); ls.ForeColor=TLT; ls.Location=Point(22,98); ls.Size=Size(406,18); frm.Controls.Add(ls)
badge(frm,22,126,total_ok,u"עודכנו",CSUC,CSUCBG)
badge(frm,22+146,126,total_sk,u"דולגו",CWRN if total_sk else TLT,CWRNBG if total_sk else BG2)
badge(frm,22+292,126,total_fl,u"נכשלו",CERR if total_fl else TLT,CERRBG if total_fl else BG2)
sep2=Panel(); sep2.BackColor=Color.FromArgb(229,231,235); sep2.Location=Point(22,198); sep2.Size=Size(406,1); frm.Controls.Add(sep2)
if skipped_details or failed_details:
    bd=mkbtn(u"הצג פרטים ({})".format(total_sk+total_fl),22,214,200,40,pri=True)
    def on_d(s,e):
        show_details_dlg()
        if _zoom[0]: frm.Close()
    bd.Click+=on_d; frm.Controls.Add(bd)
bc2=mkbtn(u"סגור",290,214,138,40); bc2.Click+=lambda s,e: frm.Close(); frm.Controls.Add(bc2)
lver=Label(); lver.Text=u"Yamit Bettman  |  v2.0"; lver.Font=Font(u"Segoe UI",8)
lver.ForeColor=TLT; lver.Location=Point(22,270); lver.Size=Size(406,16); frm.Controls.Add(lver)
frm.ShowDialog()

if _zoom[0]:
    try:
        eid=ElementId(int(_zoom[0])); ids=CList[ElementId](); ids.Add(eid)
        uidoc.Selection.SetElementIds(ids); uidoc.ShowElements(eid)
    except Exception as e: print(u"שגיאה בהצגה: {}".format(e))

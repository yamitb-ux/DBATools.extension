# -*- coding: utf-8 -*-
"""
electrical_equipment_match.py
Matches a Revit Electrical Equipment Schedule to the Dekel Israeli price catalog.
"""

import csv
import re
import glob
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────
CSV_PATH        = "Electrical Equipment Schedule.csv"
FIXTURE_CSV_PATH = "Electrical Fixture Schedule.csv"
OUTPUT_PATH     = "Electrical_Equipment_Dekel_Match.xlsx"

DEKEL_GLOB_PATTERNS = [
    "dekel_electricity_08*.xlsx",
    "dekel_08_*.xlsx",
]

HEADERS = [
    "מפלס", "Family", "Type", "MCB Rating",
    "כמות", "קוד דקל", "תיאור דקל", "יחידה",
    'מחיר יחידה ₪', 'סה"כ מחיר ₪', "הערות"
]

DESCRIPTION_MAP = {
    # ── Dry Type Transformers ──────────────────────────────────────
    "DBA Transformer - Dry Type - 630 kVA":        ("08.093.0100", "שנאי יבש 630kVA"),
    "DBA Transformer - Dry Type - 800 kVA":        ("08.093.0110", "שנאי יבש 800kVA"),
    "DBA Transformer - Dry Type - 1000 kVA":       ("08.093.0120", "שנאי יבש 1000kVA"),
    "DBA Transformer - Dry Type - 1250 kVA":       ("08.093.0125", "שנאי יבש 1250kVA"),
    "DBA Transformer - Dry Type - 1600 kVA":       ("08.093.0126", "שנאי יבש 1600kVA"),
    "DBA Transformer - Dry Type - 2000 kVA":       ("08.093.0127", "שנאי יבש 2000kVA"),
    # ── Oil Type Transformers ──────────────────────────────────────
    "DBA Transformer - Oil Type - 630 kVA":        ("08.093.0040", "שנאי שמן 630kVA"),
    "DBA Transformer - Oil Type - 800 kVA":        ("08.093.0050", "שנאי שמן 800kVA"),
    "DBA Transformer - Oil Type - 1000 kVA":       ("08.093.0060", "שנאי שמן 1000kVA"),
    "DBA Transformer - Oil Type - 1250 kVA":       ("08.093.0070", "שנאי שמן 1250kVA"),
    "DBA Transformer - Oil Type - 1600 kVA":       ("08.093.0075", "שנאי שמן 1600kVA"),
    "DBA Transformer - Oil Type - 2000 kVA":       ("08.093.0077", "שנאי שמן 2000kVA"),
    # ── UPS ───────────────────────────────────────────────────────
    "DBA Uninterruptible Power Supply - 10 kVA":   ("08.048.1100", "מערכת אל-פסק 10kVA"),
    "DBA Uninterruptible Power Supply - 20 kVA":   ("08.048.1120", "מערכת אל-פסק 20kVA"),
    "DBA Uninterruptible Power Supply - 40 kVA":   ("08.048.1140", "מערכת אל-פסק 40kVA"),
    "DBA Uninterruptible Power Supply - 80 kVA":   ("08.048.1160", "מערכת אל-פסק 80kVA"),
    # ── Transformer Control Panel ──────────────────────────────────
    "DBA Transformer Control Panel":               ("08.093.0200", "קופסת פיקוד לשנאי"),
    # ── Switchboards & Panelboards ────────────────────────────────
    "DBA HV Circuit Breaker Switchboard":          ("08.095.0010", "לוח מתח גבוה - מבודד בגז"),
    # Note: Circuit Breaker Switchboard and Panelboards matched dynamically below
    # ── Other ─────────────────────────────────────────────────────
    "Diesel Emergency Power Generator":            (None, "דורש הצעת ספק / P.A"),
    "DBA Fire Alarm Control Panel":                ("08.019.0490", "רכזת גילוי אש - נקודת חיבור"),
    "DBA Fire Fighter Control Panel":              (None, "לוח כבאים - דורש תמחור מיוחד"),
    "DBA Smoke Release Windows Control Unit":      (None, "רכזת חלונות עשן - תמחור מיוחד"),
}

# ─────────────────────────────────────────────
# SWITCHBOARD: match by closest H×W dimensions (cm → mm)
# Dekel 08.061 single-cell enclosures: H/W/D in mm
# ─────────────────────────────────────────────
SWITCHBOARD_CELLS = [
    # (H_mm, W_mm, code, label)
    (400,  600, "08.061.0050", "תא פח 400×600"),
    (400,  800, "08.061.0060", "תא פח 400×800"),
    (600,  600, "08.061.0080", "תא פח 600×600"),
    (800,  600, "08.061.0090", "תא פח 800×600"),
    (800,  800, "08.061.0110", "תא פח 800×800"),
    (1000, 600, "08.061.0120", "תא פח 1000×600"),
    (1000, 800, "08.061.0130", "תא פח 1000×800"),
    (1200, 800, "08.061.0131", "תא פח 1200×800"),
    # Modular multi-cell enclosures (H/D/W) → treat as H×W
    (2000, 400, "08.061.0048", "מבנה פח מודולרי 2000×400"),
    (2000, 600, "08.061.0046", "מבנה פח מודולרי 2000×600"),
    (2000, 800, "08.061.0044", "מבנה פח מודולרי 2000×800"),
    (2000,1000, "08.061.0042", "מבנה פח מודולרי 2000×1000"),
    (2200, 400, "08.061.0040", "מבנה פח מודולרי 2200×400"),
    (2200, 600, "08.061.0030", "מבנה פח מודולרי 2200×600"),
    (2200, 800, "08.061.0020", "מבנה פח מודולרי 2200×800"),
    (2200,1000, "08.061.0010", "מבנה פח מודולרי 2200×1000"),
]

# ─────────────────────────────────────────────
# PANELBOARD: match by MCB amperage rating
# Recessed (תה"ט) and Surface (עה"ט)
# ─────────────────────────────────────────────
PANELBOARD_MCB_MAP = {
    # amperage → (recessed_code, surface_code, label_suffix)
    25:  ("08.061.0640", "08.061.0600", "12 מא\"ז"),
    40:  ("08.061.0650", "08.061.0610", "24 מא\"ז"),
    63:  ("08.061.0660", "08.061.0620", "36 מא\"ז"),
    80:  ("08.061.0670", "08.061.0630", "48 מא\"ז"),
    100: ("08.061.0675", "08.061.0632", "54 מא\"ז"),
    125: ("08.061.0680", "08.061.0635", "72 מא\"ז"),
}


def _parse_dims_cm(s: str):
    """Extract numeric dimensions from string like '100 x 60 cm' or '35x55x10 cm'.
    Returns list of values in mm."""
    nums = re.findall(r"[\d.]+", s)
    try:
        return [float(n) * 10 for n in nums]   # cm → mm
    except ValueError:
        return []


def _closest_switchboard(h_mm: float, w_mm: float):
    """Return (code, label) for the closest H×W switchboard cell."""
    best = min(
        SWITCHBOARD_CELLS,
        key=lambda r: abs(r[0] - h_mm) + abs(r[1] - w_mm)
    )
    return best[2], best[3]


def _parse_mcb_amps(s: str):
    """Extract numeric amperage from string like '25 A' or '400 A'."""
    m = re.search(r"(\d+)", s)
    return int(m.group(1)) if m else None


def _closest_mcb(amps: int):
    """Return the closest amperage key in PANELBOARD_MCB_MAP."""
    if amps in PANELBOARD_MCB_MAP:
        return amps
    keys = sorted(PANELBOARD_MCB_MAP.keys())
    return min(keys, key=lambda k: abs(k - amps))

# ─────────────────────────────────────────────
# COLORS & STYLES
# ─────────────────────────────────────────────
CLR_HEADER      = "1F3864"   # dark blue
CLR_ALT_ROW     = "F2F2F2"   # light gray
CLR_UNMAPPED    = "FFF9C4"   # light yellow
CLR_TOTAL_ROW   = "D9E1F2"   # light blue
CLR_WHITE       = "FFFFFF"

thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
CODE_RE = re.compile(r"^\d{2}\.\d{3}\.\d{4}$")

# ─────────────────────────────────────────────
# FIXTURE MAP: Family (+ optional Type) →
#   (code1, label1, code2, label2)
#   code=None → no Dekel price, label shown as note
# ─────────────────────────────────────────────
FIXTURE_MAP = {
    # ── Load Break Switches ───────────────────────────────────────
    "DBA Load Break Switch - 2P 16A":  ("08.073.0211", "מפסק פקט 2X16A", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Load Break Switch - 2P 25A":  ("08.073.0231", "מפסק פקט 2X25A", "08.019.0320", "נקודה חד-פאזי 4mm²"),
    "DBA Load Break Switch - 4P 16A":  ("08.073.0232", "מפסק פקט 4X16A", "08.019.0340", "נקודה תלת-פאזי 2.5mm²"),
    "DBA Load Break Switch - 4P 32A":  ("08.073.0233", "מפסק פקט 4X32A", "08.019.0350", "נקודה תלת-פאזי 4mm²"),
    "DBA Load Break Switch - 4P 63A":  ("08.073.0245", "מפסק פקט 4X63A", "08.019.0350", "נקודה תלת-פאזי 4mm²"),
    # ── Sockets – Mounted ─────────────────────────────────────────
    "DBA Mounted Socket - x1":         ("08.072.0023", "שקע עה\"ט x1", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Mounted Socket - x2":         ("08.072.0024", "שקע עה\"ט x2", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Mounted Socket - x3":         ("08.072.0025", "שקע עה\"ט x3", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Mounted Socket - x4":         ("08.072.0026", "שקע עה\"ט x4", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Mounted Socket - AC":         ("08.019.0100", "נקודה מזגן חד-פאזי", None, ""),
    "DBA Mounted Socket - Venta":      ("08.072.0023", "שקע עה\"ט x1 (Venta)", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    # ── Sockets – Recessed ────────────────────────────────────────
    "DBA Recessed Socket - x1":        ("08.072.0090", "שקע תה\"ט x1 בריטי", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Recessed Socket - x2":        ("08.072.0090", "שקע תה\"ט x1 בריטי ×2", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Recessed Socket - x3":        ("08.072.0090", "שקע תה\"ט x1 בריטי ×3", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Recessed Socket - x4":        ("08.072.0090", "שקע תה\"ט x1 בריטי ×4", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Recessed Socket - AC":        ("08.019.0100", "נקודה מזגן חד-פאזי", None, ""),
    "DBA Recessed Socket - Venta":     ("08.072.0090", "שקע תה\"ט (Venta)", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Recessed Switched Socket":    ("08.019.0400", "נקודה חד-פאזי 1.5mm²", None, ""),
    # ── Sockets – 3P ─────────────────────────────────────────────
    "DBA Mounted 3P Socket":           ("08.019.0430", "נקודה תלת-פאזי 1.5mm²", None, ""),
    "DBA Recessed 3P Socket":          ("08.019.0430", "נקודה תלת-פאזי 1.5mm²", None, ""),
    "DBA Recessed 3P Socket - AC":     ("08.019.0167", "נקודה מזגן תלת-פאזי", None, ""),
    # ── Sockets – Waterproof ─────────────────────────────────────
    "DBA Waterproof Mounted Socket - x1":      ("08.072.0023", "שקע עה\"ט x1", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Waterproof Mounted Socket - x2":      ("08.072.0024", "שקע עה\"ט x2", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Waterproof Mounted Socket - x3":      ("08.072.0025", "שקע עה\"ט x3", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Waterproof Mounted Socket":           ("08.019.0410", "נקודה חד-פאזי 2.5mm²", None, ""),
    "DBA Waterproof Recessed Socket - x1":     ("08.072.0090", "שקע תה\"ט x1 בריטי", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Waterproof Recessed Socket - x2":     ("08.072.0090", "שקע תה\"ט x1 בריטי ×2", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA Waterproof Recessed Socket":          ("08.019.0310", "נקודה חד-פאזי 2.5mm²", None, ""),
    # ── CEE Sockets ──────────────────────────────────────────────
    "DBA CEE Socket - 1x16A CEE":     ("08.072.0040", "שקע CEE 3 מגעים 16A", "08.019.0310", "נקודה חד-פאזי 2.5mm²"),
    "DBA CEE Socket - 3x16A CEE":     ("08.072.0060", "שקע CEE 5 מגעים 16A", "08.019.0340", "נקודה תלת-פאזי 2.5mm²"),
    # ── EV Charging ──────────────────────────────────────────────
    "DBA EV Charging Station - 60 X 25 X 25 cm 11kW":  ("08.050.0210", "עמדת טעינה MODE 3 11kW", None, ""),
    "DBA EV Charging Station - 125 x 35 x 50 cm 22kW": ("08.050.0220", "עמדת טעינה MODE 3 22kW", None, ""),
    "DBA EV Charging Station":         ("08.050.0210", "עמדת טעינה MODE 3", None, ""),
    # ── Thermostats ──────────────────────────────────────────────
    "DBA Thermostat - AC Mounted":     ("08.046.0390", "תרמוסטט אנלוגי", "08.019.0475", "נקודת תרמוסטט 1.5mm²"),
    "DBA Thermostat - AC Recessed":    ("08.046.0390", "תרמוסטט אנלוגי", "08.019.0475", "נקודת תרמוסטט 1.5mm²"),
    "DBA Thermostat - Underfloor Heating": ("08.046.0380", "תרמוסטט חימום רצפתי", "08.019.0475", "נקודת תרמוסטט 1.5mm²"),
    # ── Electric Shade / Curtain ─────────────────────────────────
    "DBA Recessed Electric Shade-Curtain": ("08.019.0800", "נקודת תריס חשמלי", None, ""),
    # ── Push Button / Doorbell ───────────────────────────────────
    "DBA Push Button":                 ("08.073.0510", "לחצן חירום פלסטי תה\"ט", None, ""),
    "DBA Recessed Doorbell":           ("08.019.0205", "נקודת פעמון", None, ""),
    # ── Grounding ────────────────────────────────────────────────
    "DBA Grounding Out":               ("08.040.0110", "פס מגולוון 30×3.5 (למ\"מ)", None, ""),
    "DBA Grounding Out - Elevator":    ("08.040.0120", "פס מגולוון 40×4 (למ\"מ)", None, ""),
    "DBA Grounding Out - Strip":       ("08.040.0120", "פס מגולוון 40×4 (למ\"מ)", None, ""),
    "DBA Grounding Down":              ("08.040.0110", "פס מגולוון 30×3.5 — מוליך הורדה", None, ""),
    "DBA Grounding Up":                ("08.040.0110", "פס מגולוון 30×3.5 — מוליך עלייה", None, ""),
    "DBA Grounding Pit":               ("08.040.0020", "שוחת ביקורת בטון Ø50", None, ""),
    "DBA Grounding Pot":               ("08.040.0025", "שוחת ביקורת פלסטית", None, ""),
    "DBA Grounding Flex Connection":   ("08.040.0100", "גשר הארקה תקני", None, ""),
    "DBA Grounding Antistatic Floor":  ("08.040.0050", "נקודת הארקה 16mm²", None, ""),
    "DBA Grounding Recessed Junction Box": ("08.026.0150", "תיבה מלבנית להארקת יסוד", None, ""),
    "DBA Recessed Grounding Junction Box": ("08.026.0150", "תיבה מלבנית להארקת יסוד", None, ""),
    # ── Junction Boxes ───────────────────────────────────────────
    "DBA Recessed Junction Box":       ("08.026.0160", "קופסת הסתעפות IP65 50×100", None, ""),
    # ── Other fixtures ───────────────────────────────────────────
    "DBA Socket Column":               ("08.072.0820", "קופסת שקעים 6+תקשורת", None, ""),
    "DBA Industrial Combi Box":        ("08.072.1000", "קופסת שירות CEE+ישראלי IP55", None, ""),
    "DBA Mounted Armatura -Bath Heater": ("08.019.0410", "נקודה חד-פאזי 2.5mm²", None, ""),
    "DBA Floor Sockets":               ("08.072.0820", "קופסת שקעים עם תקשורת", None, ""),
    # ── No Dekel code ─────────────────────────────────────────────
    "DBA Round Opening":               (None, "פתח עגול — ללא סעיף דקל", None, ""),
    "DBA Square Opening":              (None, "פתח מרובע — ללא סעיף דקל", None, ""),
    "DBA Mounted Elec Workstation":    (None, "תחנת עבודה עה\"ט — דורש תמחור מיוחד", None, ""),
    "DBA Recessed Elec WorkStation":   (None, "תחנת עבודה תה\"ט — דורש תמחור מיוחד", None, ""),
    "DBA Mounted Elec Workstation with UPS":  (None, "תחנת עבודה + UPS עה\"ט — דורש תמחור מיוחד", None, ""),
    "DBA Recessed Elec WorkStation with UPS": (None, "תחנת עבודה + UPS תה\"ט — דורש תמחור מיוחד", None, ""),
}


# ─────────────────────────────────────────────
# 1. FIND DEKEL FILE
# ─────────────────────────────────────────────
def find_dekel_file():
    for pattern in DEKEL_GLOB_PATTERNS:
        matches = sorted(glob.glob(pattern))
        if matches:
            return matches[-1]      # latest match alphabetically
    raise FileNotFoundError(
        "No Dekel file found. Place a file matching "
        "'dekel_electricity_08*.xlsx' in the current directory."
    )


# ─────────────────────────────────────────────
# 2. PARSE DEKEL CATALOG
# ─────────────────────────────────────────────
def parse_dekel(path: str) -> dict:
    """Returns {code: {title, unit, price}} from all sheets."""
    code_re = re.compile(r"^\d{2}\.\d{3}\.\d{4}$")
    catalog = {}

    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()

        # Shared strings (some files use them)
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.iter("{%s}si" % NS):
                texts = [t.text or "" for t in si.iter("{%s}t" % NS)]
                shared.append("".join(texts))

        def cell_val(c):
            is_el = c.find("{%s}is" % NS)
            if is_el is not None:
                return "".join(t.text or "" for t in is_el.iter("{%s}t" % NS))
            v_el = c.find("{%s}v" % NS)
            if v_el is None:
                return None
            t = c.get("t", "")
            if t == "s":
                try:
                    return shared[int(v_el.text)]
                except Exception:
                    return v_el.text
            try:
                return float(v_el.text)
            except Exception:
                return v_el.text

        def col_idx(ref):
            m = re.match(r"([A-Za-z]+)", ref)
            if not m:
                return 0
            idx = 0
            for ch in m.group(1).upper():
                idx = idx * 26 + (ord(ch) - ord("A") + 1)
            return idx - 1

        sheet_files = sorted([
            n for n in names
            if re.match(r"xl/worksheets/sheet\d+\.xml$", n)
        ])

        for sf in sheet_files:
            root = ET.fromstring(zf.read(sf))
            for row in root.iter("{%s}row" % NS):
                row_data = {}
                for c in row:
                    ref = c.get("r", "")
                    row_data[col_idx(ref)] = cell_val(c)
                code = "{}".format(row_data.get(0) or "").strip()
                if not code_re.match(code):
                    continue
                title = "{}".format(row_data.get(1) or "")[:150]
                unit  = "{}".format(row_data.get(2) or "")
                price = row_data.get(3)
                try:
                    price = float(price) if price else None
                except (TypeError, ValueError):
                    price = None
                catalog[code] = {"title": title, "unit": unit, "price": price}

    return catalog


# ─────────────────────────────────────────────
# 3. PARSE CSV
# ─────────────────────────────────────────────
def parse_csv(path: str) -> list:
    """Returns list of dicts with keys: Level, Family, Type, MCB Rating, Count."""
    rows = []
    with open(path, encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        headers_found = False
        for line in reader:
            if not headers_found:
                # Look for the real header row
                if line and line[0].strip() == "Level":
                    headers_found = True
                continue
            if not any(line):           # skip blank rows
                continue
            rows.append({
                "Level":      line[0].strip() if len(line) > 0 else "",
                "Family":     line[1].strip() if len(line) > 1 else "",
                "Type":       line[2].strip() if len(line) > 2 else "",
                "MCB Rating": line[3].strip() if len(line) > 3 else "",
                "Count":      line[4].strip() if len(line) > 4 else "",
            })
    return rows


# ─────────────────────────────────────────────
# 4. MATCH LOGIC
# ─────────────────────────────────────────────
def match_row(row: dict, catalog: dict) -> dict:
    family    = row["Family"]
    type_     = row["Type"]
    mcb_str   = row["MCB Rating"]

    try:
        count = int(float(row["Count"])) if row["Count"] else 1
    except ValueError:
        count = 1

    def result(code, description, unit="", note=""):
        price = catalog.get(code, {}).get("price") if code else None
        unit  = catalog.get(code, {}).get("unit", unit) if code else unit
        total = round(price * count, 2) if price is not None else None
        return {
            "code": code or "", "description": description,
            "unit": unit, "price": price, "count": count,
            "total": total, "note": note,
            "mapped": code is not None and price is not None,
            "has_entry": True,
        }

    # ── 1. DBA Circuit Breaker Switchboard → match by dimensions ──
    if family == "DBA Circuit Breaker Switchboard":
        dims = _parse_dims_cm(type_)
        if len(dims) >= 2:
            code, label = _closest_switchboard(dims[0], dims[1])
            return result(code, f"לוח ראשי — מבנה פח {label}")
        return result(None, "לוח ראשי — לא ניתן לפרש מידות",
                      note="בדוק מידות ב-Type")

    # ── 2. DBA Panelboard Recessed → match by MCB amperage ────────
    if family == "DBA Panelboard - 400V MCB - Recessed":
        amps = _parse_mcb_amps(mcb_str)
        if amps:
            key = _closest_mcb(amps)
            rec_code, _, suffix = PANELBOARD_MCB_MAP[key]
            return result(rec_code,
                          f"לוח תחת הטיח {amps}A — {suffix}",
                          note="" if amps in PANELBOARD_MCB_MAP else
                               f"הוחלף לאמפר קרוב {key}A")
        return result(None, "לוח תחת הטיח — MCB Rating חסר",
                      note="הכנס MCB Rating")

    # ── 3. DBA Panelboard Surface → match by MCB amperage ─────────
    if family == "DBA Panelboard - 400V MCB - Surface":
        amps = _parse_mcb_amps(mcb_str)
        if amps:
            key = _closest_mcb(amps)
            _, surf_code, suffix = PANELBOARD_MCB_MAP[key]
            return result(surf_code,
                          f"לוח על הטיח {amps}A — {suffix}",
                          note="" if amps in PANELBOARD_MCB_MAP else
                               f"הוחלף לאמפר קרוב {key}A")
        return result(None, "לוח על הטיח — MCB Rating חסר",
                      note="הכנס MCB Rating")

    # ── 4. Standard DESCRIPTION_MAP lookup ────────────────────────
    for key in [f"{family} - {type_}", family]:
        if key in DESCRIPTION_MAP:
            code, description = DESCRIPTION_MAP[key]
            return result(code, description,
                          note=description if code is None else "")

    return {
        "code": "", "description": "", "unit": "",
        "price": None, "count": count, "total": None,
        "note": "לא נמצאה התאמה", "mapped": False, "has_entry": False,
    }


# ─────────────────────────────────────────────
# 5. BUILD EXCEL OUTPUT
# ─────────────────────────────────────────────
def build_excel(csv_rows: list, catalog: dict, output_path: str):
    wb = Workbook()
    ws = wb.active
    ws.title = "התאמת ציוד חשמלי"
    ws.sheet_view.rightToLeft = True

    # ── Header row ──
    header_fill = PatternFill("solid", fgColor=CLR_HEADER)
    header_font = Font(name="Arial", bold=True, color=CLR_WHITE, size=11)
    center      = Alignment(horizontal="center", vertical="center",
                            wrap_text=True, readingOrder=2)
    right_align = Alignment(horizontal="right",  vertical="center",
                            wrap_text=True, readingOrder=2)

    ws.append(HEADERS)
    for col_idx, _ in enumerate(HEADERS, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = center
        cell.border    = BORDER

    ws.row_dimensions[1].height = 30

    # ── Data rows ──
    matched = skipped = no_price = 0
    data_rows = []

    for item in csv_rows:
        m = match_row(item, catalog)
        data_rows.append((item, m))

        try:
            count = int(float(item["Count"])) if item["Count"] else 1
        except ValueError:
            count = 1

        row_data = [
            item["Level"],
            item["Family"],
            item["Type"],
            item["MCB Rating"],
            count,
            m["code"],
            m["description"],
            m["unit"],
            m["price"],
            m["total"],
            m["note"],
        ]
        ws.append(row_data)

        row_num   = ws.max_row
        is_alt    = (row_num % 2 == 0)
        is_mapped = m["has_entry"] and m["mapped"]
        is_noted  = m["has_entry"] and not m["mapped"]

        if is_noted:
            row_fill = PatternFill("solid", fgColor=CLR_UNMAPPED)
        elif is_alt:
            row_fill = PatternFill("solid", fgColor=CLR_ALT_ROW)
        else:
            row_fill = PatternFill("solid", fgColor=CLR_WHITE)

        price_fmt = '#,##0.00'
        for col_idx in range(1, len(HEADERS) + 1):
            cell = ws.cell(row=row_num, column=col_idx)
            cell.font      = Font(name="Arial", size=10)
            cell.fill      = row_fill
            cell.border    = BORDER
            cell.alignment = right_align
            if col_idx in (9, 10):   # price columns
                cell.number_format = price_fmt

        if is_mapped:
            matched += 1
        elif is_noted:
            no_price += 1
        else:
            skipped += 1

    # ── Total row ──
    total_row = ws.max_row + 1
    data_start = 2
    data_end   = total_row - 1

    total_fill = PatternFill("solid", fgColor=CLR_TOTAL_ROW)
    total_font = Font(name="Arial", bold=True, size=11)
    bold_right = Alignment(horizontal="right", vertical="center", readingOrder=2)

    ws.cell(row=total_row, column=1).value = 'סה"כ'
    ws.cell(row=total_row, column=10).value = (
        f"=SUM(J{data_start}:J{data_end})"
    )

    for col_idx in range(1, len(HEADERS) + 1):
        cell = ws.cell(row=total_row, column=col_idx)
        cell.font      = total_font
        cell.fill      = total_fill
        cell.border    = BORDER
        cell.alignment = bold_right
        if col_idx == 10:
            cell.number_format = '#,##0.00'

    # ── Column widths ──
    col_widths = [32, 34, 22, 14, 8, 16, 38, 8, 16, 16, 34]
    for i, width in enumerate(col_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    ws.freeze_panes = "A2"

    wb.save(output_path)
    return matched, no_price, skipped, len(csv_rows)


# ─────────────────────────────────────────────
# 6. FIXTURE CSV
# ─────────────────────────────────────────────
def parse_fixture_csv(path: str) -> list:
    rows = []
    with open(path, encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        headers_found = False
        for line in reader:
            line += [""] * 12
            if not headers_found:
                if line[0].strip() == "Level":
                    headers_found = True
                continue
            if not any(line[:5]):
                continue
            rows.append({
                "Level":      line[0].strip(),
                "Family":     line[1].strip(),
                "Type":       line[2].strip(),
                "Description":line[3].strip(),
                "Count":      line[4].strip(),
                "pre_code1":  line[5].strip(),
                "pre_desc1":  line[6].strip(),
                "pre_code2":  line[7].strip(),
                "pre_desc2":  line[8].strip(),
            })
    return rows


def match_fixture_row(row: dict, catalog: dict) -> dict:
    family = row["Family"]
    type_  = row["Type"]

    try:
        count = int(float(row["Count"])) if row["Count"] else 1
    except ValueError:
        count = 1

    def make_result(code1, label1, code2, label2, note=""):
        p1 = catalog.get(code1, {}).get("price") if code1 else None
        p2 = catalog.get(code2, {}).get("price") if code2 else None
        u1 = catalog.get(code1, {}).get("unit", "") if code1 else ""
        u2 = catalog.get(code2, {}).get("unit", "") if code2 else ""
        # Use catalog titles if available, fall back to label
        t1 = catalog.get(code1, {}).get("title", label1)[:60] if code1 else label1
        t2 = catalog.get(code2, {}).get("title", label2)[:60] if code2 else label2
        total = round(((p1 or 0) + (p2 or 0)) * count, 2) if (p1 or p2) else None
        has_price = (p1 is not None or p2 is not None)
        return {
            "code1": code1 or "", "label1": t1 or label1, "price1": p1, "unit1": u1,
            "code2": code2 or "", "label2": t2 or label2, "price2": p2, "unit2": u2,
            "count": count, "total": total, "note": note,
            "has_price": has_price,
        }

    # ── Pre-filled codes from CSV take priority ──
    c1 = row["pre_code1"] if CODE_RE.match(row["pre_code1"]) else ""
    c2 = row["pre_code2"] if CODE_RE.match(row["pre_code2"]) else ""
    if c1 or c2:
        l1 = row["pre_desc1"] if c1 else ""
        l2 = row["pre_desc2"] if c2 else ""
        return make_result(c1 or None, l1, c2 or None, l2, note="קוד ממוזן מ-Revit")

    # ── FIXTURE_MAP lookup: Family-Type → Family ──
    for key in [f"{family} - {type_}", family]:
        if key in FIXTURE_MAP:
            c1, l1, c2, l2 = FIXTURE_MAP[key]
            note = l1 if not c1 else ""
            return make_result(c1, l1, c2, l2, note=note)

    return make_result(None, "", None, "",
                       note="לא נמצאה התאמה")


FIXTURE_HEADERS = [
    "מפלס", "Family", "Type", "תיאור", "כמות",
    "קוד דקל 1", "תיאור דקל 1", "יחידה", "מחיר 1 ₪",
    "קוד דקל 2", "תיאור דקל 2", "יחידה 2", "מחיר 2 ₪",
    "סה\"כ מחיר ₪", "הערות"
]


def build_fixture_sheet(wb, fixture_rows: list, catalog: dict):
    ws = wb.create_sheet("Electrical Fixtures")
    ws.sheet_view.rightToLeft = True

    header_fill = PatternFill("solid", fgColor=CLR_HEADER)
    header_font = Font(name="Arial", bold=True, color=CLR_WHITE, size=11)
    center      = Alignment(horizontal="center", vertical="center",
                            wrap_text=True, readingOrder=2)
    right_align = Alignment(horizontal="right", vertical="center",
                            wrap_text=True, readingOrder=2)

    ws.append(FIXTURE_HEADERS)
    for col_idx in range(1, len(FIXTURE_HEADERS) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = header_font; cell.fill = header_fill
        cell.alignment = center; cell.border = BORDER
    ws.row_dimensions[1].height = 30

    matched = no_price = unmatched = 0

    for item in fixture_rows:
        m = match_fixture_row(item, catalog)
        row_data = [
            item["Level"], item["Family"], item["Type"], item["Description"],
            m["count"],
            m["code1"], m["label1"], m["unit1"], m["price1"],
            m["code2"], m["label2"], m["unit2"], m["price2"],
            m["total"], m["note"],
        ]
        ws.append(row_data)
        row_num = ws.max_row
        is_alt  = (row_num % 2 == 0)

        if not m["code1"] and not m["code2"]:
            fill = PatternFill("solid", fgColor=CLR_UNMAPPED)
            unmatched += 1
        elif m["has_price"]:
            fill = PatternFill("solid", fgColor=CLR_ALT_ROW if is_alt else CLR_WHITE)
            matched += 1
        else:
            fill = PatternFill("solid", fgColor=CLR_UNMAPPED)
            no_price += 1

        price_cols = {9, 13, 14}
        for ci in range(1, len(FIXTURE_HEADERS) + 1):
            cell = ws.cell(row=row_num, column=ci)
            cell.font = Font(name="Arial", size=10)
            cell.fill = fill; cell.border = BORDER
            cell.alignment = right_align
            if ci in price_cols:
                cell.number_format = "#,##0.00"

    # Total row
    total_row = ws.max_row + 1
    total_fill = PatternFill("solid", fgColor=CLR_TOTAL_ROW)
    total_font = Font(name="Arial", bold=True, size=11)
    bold_right = Alignment(horizontal="right", vertical="center", readingOrder=2)
    ws.cell(row=total_row, column=1).value = 'סה"כ'
    ws.cell(row=total_row, column=14).value = f"=SUM(N2:N{total_row-1})"
    for ci in range(1, len(FIXTURE_HEADERS) + 1):
        cell = ws.cell(row=total_row, column=ci)
        cell.font = total_font; cell.fill = total_fill
        cell.border = BORDER; cell.alignment = bold_right
        if ci == 14:
            cell.number_format = "#,##0.00"

    col_widths = [28, 30, 22, 22, 7, 16, 38, 7, 14, 16, 38, 7, 14, 14, 28]
    for i, w in enumerate(col_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"

    return matched, no_price, unmatched, len(fixture_rows)


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main():
    print("=" * 55)
    print("  Electrical Equipment + Fixtures → Dekel Matcher")
    print("=" * 55)

    dekel_path = find_dekel_file()
    print(f"\n  Dekel file : {dekel_path}")

    print("  Parsing Dekel catalog...", end=" ", flush=True)
    catalog = parse_dekel(dekel_path)
    print(f"{len(catalog)} items loaded.")

    # ── Equipment sheet ──
    print("  Parsing Equipment CSV...", end=" ", flush=True)
    csv_rows = parse_csv(CSV_PATH)
    print(f"{len(csv_rows)} rows found.")

    # ── Fixture sheet ──
    fixture_rows = []
    has_fixtures = False
    import os
    if os.path.exists(FIXTURE_CSV_PATH):
        print(f"  Parsing Fixture CSV...", end=" ", flush=True)
        fixture_rows = parse_fixture_csv(FIXTURE_CSV_PATH)
        has_fixtures = True
        print(f"{len(fixture_rows)} rows found.")
    else:
        print(f"  Fixture CSV not found ({FIXTURE_CSV_PATH}) — skipping.")

    # ── Build workbook ──
    print("  Generating Excel output...", end=" ", flush=True)
    matched, no_price, skipped, total = build_excel(csv_rows, catalog, OUTPUT_PATH)
    print("done.")

    if has_fixtures:
        from openpyxl import load_workbook
        wb2 = load_workbook(OUTPUT_PATH)
        fm, fn, fu, ft = build_fixture_sheet(wb2, fixture_rows, catalog)
        wb2.save(OUTPUT_PATH)
        print(f"""
  ┌──────────────────────────────────────────┐
  │  Output : {OUTPUT_PATH:<32}│
  │                                          │
  │  Equipment Schedule ({total} rows):            │
  │    Matched (priced)  : {matched:<18}│
  │    Noted (no price)  : {no_price:<18}│
  │    Unmatched         : {skipped:<18}│
  │                                          │
  │  Fixture Schedule ({ft} rows):              │
  │    Matched (priced)  : {fm:<18}│
  │    Noted (no price)  : {fn:<18}│
  │    Unmatched         : {fu:<18}│
  └──────────────────────────────────────────┘
""")
    else:
        print(f"""
  ┌──────────────────────────────────┐
  │  Output : {OUTPUT_PATH:<24}│
  │  Total rows    : {total:<16}│
  │  Matched (priced)  : {matched:<12}│
  │  Noted (no price)  : {no_price:<12}│
  │  Unmatched         : {skipped:<12}│
  └──────────────────────────────────┘
""")


if __name__ == "__main__":
    main()
